local package_id = "com.louise.HauntedCandle"
local character_id = "com.louise.enemy.HauntedCandle"

function package_requires_scripts()
  Engine.define_character(character_id .. "HauntedCandle", _modpath.."HauntedCandle")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("HauntedCandle")
  package:set_description("B6 HauntedCandle Battle!")
  package:set_speed(1)
  package:set_attack(50)
  package:set_health(150)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
local spawner = mob:create_spawner(character_id .. "HauntedCandle",Rank.V1)
spawner:spawn_at(4, 1)
local spawner = mob:create_spawner(character_id .. "HauntedCandle",Rank.V2)
spawner:spawn_at(4, 3)
local spawner = mob:create_spawner(character_id .. "HauntedCandle",Rank.V3)
spawner:spawn_at(6, 1)

local spawner = mob:create_spawner(character_id .. "HauntedCandle",Rank.SP)
spawner:spawn_at(6, 3)
local spawner = mob:create_spawner(character_id .. "HauntedCandle",Rank.Rare2)
spawner:spawn_at(5, 2)
end
