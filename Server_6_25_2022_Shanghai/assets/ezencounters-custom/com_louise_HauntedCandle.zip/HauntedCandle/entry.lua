local shared_package_init = include("./character.lua")
local character_id = "com.louise.enemy."
function package_init(character)
    local character_info = {
        name="HauntedCandle",
        hp=150,
        damage=50,
        palette=_folderpath.."V1.png",
        height=80,
    }
    if character:get_rank() == Rank.V2 then
        character_info.damage = 80
        character_info.palette=_folderpath.."V2.png"
        character_info.hp = 200
    elseif character:get_rank() == Rank.V3 then
        character_info.damage = 130
        character_info.palette=_folderpath.."V3.png"
        character_info.hp = 240
    elseif character:get_rank() == Rank.SP then
        character_info.damage = 150
        character_info.palette=_folderpath.."SP.png"
        character_info.hp = 280
    elseif character:get_rank() == Rank.Rare1 then
        character_info.damage = 100
        character_info.palette=_folderpath.."R1.png"
        character_info.hp = 200
    elseif character:get_rank() == Rank.Rare2 then
        character_info.damage = 150
        character_info.palette=_folderpath.."R2.png"
        character_info.hp = 280
    end
    shared_package_init(character,character_info)
end
