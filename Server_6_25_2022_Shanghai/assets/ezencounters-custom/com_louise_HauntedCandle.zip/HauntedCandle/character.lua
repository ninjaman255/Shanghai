local battle_helpers = include("battle_helpers.lua")
local character_animation = _folderpath.."battle.animation"
--local shockwave_spawn = 3
local anim_speed = 1
local flame_sfx = Engine.load_audio(_folderpath .. "burn.ogg")
local flame_texture = Engine.load_texture(_folderpath .. "flame.png")
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.png")
local flame_anim = _folderpath .. "flame.animation"
local flame_delay=34

local impacts_texture = Engine.load_texture(_folderpath .. "impacts.png")
local impacts_animation_path = _folderpath .. "impacts.animation"

local MobTracker = include("mob_tracker.lua")
local left_mob_tracker = MobTracker:new()
local right_mob_tracker = MobTracker:new()

function package_init(self, character_info)
    -- Required function, main package information
    -- Load character resources
    local base_animation_path = character_animation
	self:set_texture(CHARACTER_TEXTURE, true)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
	self.animation:set_playback_speed(anim_speed)
    -- Load extra resources
    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.damage=(character_info.damage)
    self:share_tile(false)
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0, 0)
    self:set_palette(Engine.load_texture(character_info.palette))
	self.animation:set_state("IDLE")
	self.animation:set_playback(Playback.Loop)
    self.frame_counter=0
    self.frames_between_actions = 100 
    self.started = false
    self.state = "idle"
    self.look_direction = "downtoup"
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.next_look_anim = nil

    self.defense_rule = Battle.DefenseRule.new(0,DefenseOrder.Always)
    self.defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.element == Element.Wind then
            if(self.state ~= "Melted")then
                self.animation:set_state("MELT")
                self.state="Melted"
            end
            return
        elseif(attacker_hit_props.element == Element.Fire) then
        judge:block_impact()
        judge:block_damage()
        if(self.state=="Melted") then
            self.animation:set_state("IDLE")
            self.animation:set_playback(Playback.Loop)
            self.state="idle"
            
        end
    end
end
    self:add_defense_rule(self.defense_rule)

    
    -- mob tracker stuff.

    self.battle_start_func = function(self)
        add_enemy_to_tracking(self)
        local field = self:get_field()
        local mob_sort_func = function(a,b)
            local met_a_tile = field:get_entity(a):get_current_tile()
            local met_b_tile = field:get_entity(b):get_current_tile()
            local var_a = (met_a_tile:x()*3)+met_a_tile:y()
            local var_b = (met_b_tile:x()*3)+met_b_tile:y()
            return var_a < var_b
        end
        left_mob_tracker:sort_turn_order(mob_sort_func)
        right_mob_tracker:sort_turn_order(mob_sort_func,true)--reverse sort direction
    end
    self.on_spawn_func = function(self, spawn_tile)
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.delete_func = function(self) 
        remove_enemy_from_tracking(self)
    end

    self.flame_action = function ()
        self.animation:set_state("PREPARE_ATTACK")
        self.animation:on_complete(function ()
            self.animation:set_state("ATTACKING")
            self.animation:set_playback(Playback.Loop)
            self.state = "attacking"    
            local flame_tiles = find_4_tiles(self)
            local flame1 = nil
            for index, value in pairs(flame_tiles) do
                
                spawn_flame(self, value, self.damage) 
            end
            
            end)
        end

    

	self.update_func = function ()
        if(self.state == "idle") then
            local active_mob_id = get_active_mob_id_for_same_direction(self:get_facing())   
                if active_mob_id == self:get_id() then
                    if(self.frame_counter >= self.frames_between_actions) then  
                    self:flame_action()
                    self.frame_counter=0
                    self.state = "prepare_attack"
                end
                self.frame_counter=self.frame_counter+1
            end
       
        elseif self.state == "attacking" then
            if(self.frame_counter==24) then
                self:toggle_counter(true)
                Engine.play_audio(flame_sfx, AudioPriority.Highest)
            end
            if(self.frame_counter==38) then
                self:toggle_counter(false)
            end
            self.frame_counter=self.frame_counter+1
            if(self.frame_counter==150) then
            --back to idling after flame is gone. unless it melted
                self.animation:set_state("IDLE")
                self.animation:set_playback(Playback.Loop)
                self.state="idle"
                self.frame_counter=0
                advance_a_turn_by_facing(self:get_facing())
            end
        elseif self.state == "Melted" then
            --skip its turn if melted.
            local active_mob_id = get_active_mob_id_for_same_direction(self:get_facing())
            if active_mob_id == self:get_id() then
                advance_a_turn_by_facing(self:get_facing())
            end
        end
    end
end


function spawn_flame(owner, tile, damage)
    local owner_id = owner:get_id()
    local team = owner:get_team()
    local field = owner:get_field()
    local cascade_frame = cascade_frame_index
        if not tile:is_walkable() then 
            if(not owner:is_deleted()) then
                -- local facing = owner:get_facing()
                -- owner.ai_taken_turn = false
                -- owner.attacking = false
                -- advance_a_turn_by_facing(facing)
            end
            return end

        

        local spell = Battle.Spell.new(team)
        
        spell:set_hit_props(HitProps.new(damage, Hit.Flash | Hit.Flinch, Element.Fire, owner_id, Drag.new()))

        local sprite = spell:sprite()
        sprite:set_texture(flame_texture)
        sprite:set_layer(-1)
        spell.wait_frames=0

        local animation = spell:get_animation()
       
        spell:hide()

        spell.update_func = function()
            --flame delay
            if(spell.wait_frames<flame_delay) then
                spell:highlight_tile(Highlight.Flash)
            end
            if(spell.wait_frames==flame_delay) then
                spell.flame_frames = 0
                spell:reveal()
                spell:highlight_tile(Highlight.None)
                animation:load(flame_anim)
                animation:set_state("FLAME_START")
                animation:refresh(sprite)
                animation:on_complete(function() 
                    animation:set_state("FLAME_REPEAT")
                    animation:set_playback(Playback.Loop)
                    animation:refresh(sprite)
                end)
                
            end
            --end flame delay
            if(spell.wait_frames>flame_delay) then
                spell:get_current_tile():attack_entities(spell)
                spell.flame_frames = spell.flame_frames+1
                --flame lasts for about 132 flames so play the despawn anim at 129
                if(spell.flame_frames==129) then
                    animation:set_state("FLAME_END")
                    animation:refresh(sprite)
                    animation:on_complete(function() 
                        spell:erase()
                    end)
                end
            end
            spell.wait_frames=spell.wait_frames+1
            
        end
        spell.collision_func = function(self, other)
            local artifact = Battle.Artifact.new()
            artifact:never_flip(true)
            artifact:set_texture(impacts_texture)
            artifact:set_animation(impacts_animation_path)
            --FX
            local anim = artifact:get_animation()
            anim:set_state("flame_impact")
            anim:on_complete(function()
                artifact:erase()
            end)
            --flame is put out on contact
            spell:erase()
            field:spawn(artifact, tile)
        end
        field:spawn(spell, tile)
        return spell
end

function find_4_tiles(self)
    local target_char = find_target(self)
    local target_tile = target_char:get_tile()
    local tilePatterns = {}
    local team = self:get_team()
    insert_if_not_null(tilePatterns, getAdjTiles(team,target_tile:get_tile(Direction.UpLeft,1)))
    insert_if_not_null(tilePatterns, getAdjTiles(team,target_tile:get_tile(Direction.Up,1)))
    insert_if_not_null(tilePatterns, getAdjTiles(team,target_tile:get_tile(Direction.Left,1)))
    insert_if_not_null(tilePatterns, getAdjTiles(team,target_tile))
    return tilePatterns[math.random(1, #tilePatterns)]
end

  

function insert_if_not_null(tbl, val)
    if(val ~= nil) then
    table.insert(tbl, val)
    end
end
  --get the the tiles to the right, downright, and down;
    -- edges shouldnt be considered
function getAdjTiles(team, target_tile)
    local tile_arr = {}
    local tile2 = target_tile:get_tile(Direction.Right, 1)
    local tile3 = target_tile:get_tile(Direction.DownRight, 1)
    local tile4 =  target_tile:get_tile(Direction.Down, 1)
    --do not select this group if top and bottom tile owned by team.
    local extraCheck = tile2:get_team()==team and tile3:get_team()==team
    local extraCheck2 = target_tile:get_team()==team and tile4:get_team()==team
    if(not extraCheck and not extraCheck2 and not target_tile:is_edge() and not tile2:is_edge() and not tile3:is_edge() and not tile4:is_edge())
    then
        table.insert(tile_arr, tile2)
        table.insert(tile_arr, tile3)
        table.insert(tile_arr,tile4)
        table.insert(tile_arr, target_tile)
    else
        return nil
    end
    return tile_arr
end

function find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        return
    end
    local target_character = target_list[1]
    return target_character
end



function tiletostring(tile) 
    return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
end

function get_tracker_from_direction(facing)
    if facing == Direction.Left then
        return left_mob_tracker
    elseif facing == Direction.Right then
        return right_mob_tracker
    end
end

function advance_a_turn_by_facing(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:advance_a_turn()
end

function get_active_mob_id_for_same_direction(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:get_active_mob()
end

function add_enemy_to_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:add_by_id(id)
end

function remove_enemy_from_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:remove_by_id(id)
end

return package_init