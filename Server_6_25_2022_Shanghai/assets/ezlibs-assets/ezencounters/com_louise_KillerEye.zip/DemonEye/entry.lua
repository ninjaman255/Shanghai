local shared_package_init = include("../KillerEye/character.lua")
local character_id = "com.louise_enemy_"
function package_init(character)
    local character_info = {
        name="DemonEye",
        hp=150,
        damage=100,
        palette=_folderpath.."palette.png",
        height=80,
    }
    shared_package_init(character,character_info)
end
