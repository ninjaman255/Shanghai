local package_id = "com.louise.KillerEye"
local character_id = "com.louise.enemy."

function package_requires_scripts()
  Engine.define_character(character_id .. "KillerEye", _modpath.."KillerEye")
  Engine.define_character(character_id .. "DemonEye", _modpath.."DemonEye")
  Engine.define_character(character_id .. "JokerEye", _modpath.."JokerEye")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("KillerEye")
  package:set_description("Bn6 KillerEye Battle!")
  package:set_speed(1)
  package:set_attack(50)
  package:set_health(100)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
local spawner = mob:create_spawner(character_id .. "KillerEye",Rank.V1)
spawner:spawn_at(4, 1)
spawner = mob:create_spawner(character_id.. "DemonEye",Rank.V1)
spawner:spawn_at(4, 3)
spawner = mob:create_spawner(character_id.."JokerEye",Rank.V1)
spawner:spawn_at(6, 1)

local spawner = mob:create_spawner(character_id .. "KillerEye",Rank.SP)
spawner:spawn_at(6, 3)
-- spawner = mob:create_spawner(character_id .. "KillerEye",Rank.Rare1)
-- spawner:spawn_at(5, 3)
-- spawner = mob:create_spawner(character_id .. "KillerEye",Rank.Rare2)
-- spawner:spawn_at(5, 2)
end
