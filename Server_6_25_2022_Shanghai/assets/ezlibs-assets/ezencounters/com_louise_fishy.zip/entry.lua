local package_id = "com.louise.Fishy"
local character_id = "com.louise.enemy.Fishy"

function package_requires_scripts()
  Engine.define_character(character_id, _modpath.."Fishy")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Fishy")
  package:set_description("BN3 Fishy Battle!")
  package:set_speed(1)
  package:set_attack(30)
  package:set_health(90)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function get_package(name) 
  return character_package_prefix..name
end

function package_build(mob)

local spawner = mob:create_spawner(character_id,Rank.V1)
spawner:spawn_at(6,1)

local spawner = mob:create_spawner(character_id,Rank.V2)
spawner:spawn_at(5, 2)

local spawner = mob:create_spawner(character_id,Rank.V3)
spawner:spawn_at(4, 3)

-- local spawner = mob:create_spawner(character_id,Rank.SP)
-- spawner:spawn_at(6,3)

end

return package_init