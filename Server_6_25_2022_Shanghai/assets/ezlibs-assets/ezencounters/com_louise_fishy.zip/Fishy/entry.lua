local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name="Fishy",
        hp=90,
        damage=50,
        palette=_folderpath.."V1.png",
        height=80,
        flydelay = 10,
        floatdelay = 30,
        dashes = 2,
    }
    if character:get_rank() == Rank.V2 then
        character_info.damage = 60
        character_info.flydelay = 10
        character_info.floatdelay = 30
        character_info.dashes = 1
        character_info.hp = 150
        character_info.element = "fire"
        character_info.flame_trail = true
        character_info.palette=_folderpath.."V2.png"
    elseif character:get_rank() == Rank.V3 then
        character_info.damage = 90
        character_info.flydelay = 6
        character_info.floatdelay = 30
        character_info.dashes = 3
        character_info.hp = 150
        character_info.palette=_folderpath.."V3.png"
        character_info.hp = 240
    elseif character:get_rank() == Rank.SP then
        character_info.damage = 150
        character_info.flydelay = 5
        character_info.floatdelay = 30
        character_info.dashes = 5
        character_info.palette=_folderpath.."SP.png"
        character_info.hp = 300
    -- elseif character:get_rank() == Rank.Rare1 then
    --     character_info.damage = 50
    --     character_info.palette=_folderpath.."battle_vrare1.palette.png"
    --     character_info.hp = 120
    --     character_info.cascade_frame = 3
    --     character_info.move_delay = 22
    -- elseif character:get_rank() == Rank.Rare2 then
    --     character_info.damage = 100
    --     character_info.palette=_folderpath.."battle_vrare2.palette.png"
    --     character_info.hp = 180
    --     character_info.cascade_frame = 3
    --     character_info.move_delay = 20
    end
    shared_package_init(character,character_info)
end
