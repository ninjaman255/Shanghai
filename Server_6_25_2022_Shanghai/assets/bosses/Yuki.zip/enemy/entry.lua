local texture = nil
local alert = nli
local shadow_texture = nil
local anim = nil

local THROW_SFX = nil
local FIRE_PROJECTILE_SFX = nil
local FIRE_KICK = nil
local FLAME_PILLAR_SFX = nil
local SEARCH_SFX = nil
local LOCK_ON_SFX = nil
local APPEAR_SFX = nil
local BREAK_SFX = nil
local SPIN_SFX = nil
local SNAKE_SFX = nil
local APOLLO_SFX = nil
local EXPLOSION_SFX = nil

local HIT_SFX = nil

function package_init(self)
    texture = Engine.load_texture(_modpath.."Yuki.png")
    alert = Engine.load_texture(_modpath.."overlay_fx07_animations.png")
    self:set_name("Yuki")
	local rank = self:get_rank()
    self.damage = 90

	if rank == Rank.V1 then
    	self:set_health(2100)
	else
		self:set_health(2700)

	end
	self:set_element(Element.Fire)
    self:set_texture(texture, true)
    self:set_height(60)
    self:share_tile(false)
    self.max_health = self:get_health()
    self:set_explosion_behavior(8, 8, true)


    anim = self:get_animation()
    anim:load(_modpath.."Yuki.animation")
    anim:set_state("IDLE")
    anim:set_playback(Playback.Loop)
    
    THROW_SFX = Engine.load_audio(_folderpath.."throw.ogg")
    FIRE_PROJECTILE_SFX = Engine.load_audio(_folderpath.."FireProjectile.ogg")
    FIRE_KICK = Engine.load_audio(_folderpath.."FireKick.ogg")
    FLAME_PILLAR_SFX = Engine.load_audio(_folderpath.."FlamePillar.ogg")
    SEARCH_SFX = Engine.load_audio(_folderpath.."Search.ogg")
    LOCK_ON_SFX = Engine.load_audio(_folderpath.."LockOn.ogg")
    BREAK_SFX = Engine.load_audio(_folderpath.."break.ogg")
    SPIN_SFX = Engine.load_audio(_folderpath.."Spin.ogg")
    APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
    SNAKE_SFX = Engine.load_audio(_folderpath.."quake.ogg")
    APOLLO_SFX = Engine.load_audio(_folderpath.."ApolloSoul.ogg")
    EXPLOSION_SFX = Engine.load_audio(_folderpath.."explosion.ogg")

    HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")



    init_boss(self)

end

function init_boss(self)
    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        move_line_up = {name = "move_line_up", func = move_line_up},
        move_to_back = {name = "move_to_back", func = move_to_back},
        move_to_back_center = {name = "move_to_back_center", func = move_to_back_center},
        move_near_front = {name = "move_near_front", func = move_near_front},
        move_to_enemy = {name = "move_to_enemy", func = move_to_enemy},
        move_to_column_in_front_of_target = {name = "move_to_column_in_front_of_target", func = move_to_column_in_front_of_target},
        
        fire_shot = {name = "fire_shot", func = fire_shot},
        combo = {name = "combo", func = combo},
        spin_kick_down = {name = "spin_kick_down", func = spin_kick_down},
        spin_kick_up = {name = "spin_kick_up", func = spin_kick_up},
        spin_kick_back = {name = "spin_kick_back", func = spin_kick_back},
        spin_kick_column = {name = "spin_kick_column", func = spin_kick_column},
        choose_kick = {name = "choose_kick", func = choose_kick},
        throw = {name = "throw", func = throw},
        fire_search = {name = "fire_search", func = fire_search},
        fire_snake = {name = "fire_snake", func = fire_snake}

        
    }
    
    local elem_defense = Battle.DefenseRule.new(224,DefenseOrder.CollisionOnly)

    elem_defense.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.damage > 0 then
            if self.apollo_active and attacker_hit_props.element == Element.Aqua then 
                attacker_hit_props.damage = math.floor(attacker_hit_props.damage*0.9)
                attacker:set_hit_props(attacker_hit_props)

            end

            if attacker:get_name() == "Element.Earth" then 
                attacker_hit_props = attacker:copy_hit_props()
                attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                attacker:set_hit_props(attacker_hit_props)

                local alert = graphic_init("artifact", 32, 0, alert, "overlay_fx07_animations.animation", -9, "0", defender, defender:get_facing(), true)
                local y = defender:get_height()+14
                if y < 20 then 
                    y = 40
                end
                alert:set_elevation(y)
                defender:get_field():spawn(alert, defender:get_current_tile())

            end

        end


    end

    self:add_defense_rule(elem_defense)

    local s = self.states
    
      
    self.pattern = {
        s.idle, s.idle, 

        s.start_sub_pattern,
            s.throw, s.move, s.throw, s.move, s.throw,
        s.finish_sub_pattern, s.move, s.idle, s.idle
        
        
    }

    self.pattern = {
        s.idle, s.idle, s.move, s.idle, s.idle,

        s.start_sub_pattern,
            s.move_line_up, s.fire_shot, s.move_line_up, s.fire_shot, s.move_to_enemy, s.combo, s.move_to_enemy, s.combo,
        s.finish_sub_pattern, s.move,

        s.fire_search, 
       
    }

    self.pattern = {
        s.idle, s.idle, s.move,

        s.choose_kick,
        s.choose_kick,
        s.choose_kick,

        s.start_sub_pattern, 
            s.move_to_column_in_front_of_target, s.spin_kick_column,
        s.finish_sub_pattern, s.move
    }


    self.pattern = {
        s.idle, s.idle, s.move, s.idle, s.idle,

        s.start_sub_pattern,
            s.move_line_up, s.fire_shot, s.move_line_up, s.fire_shot, s.move_to_enemy, s.combo, s.move_to_enemy, s.combo,
        s.finish_sub_pattern, s.move,

        s.idle, s.idle, 

        s.choose_kick,
        s.choose_kick,
        s.choose_kick,

        s.start_sub_pattern, 
            s.move_to_column_in_front_of_target, s.spin_kick_column,
        s.finish_sub_pattern, s.move,

        s.idle, s.idle, s.move,

        s.start_sub_pattern,
            s.throw, s.move, s.throw, s.move, s.throw,
        s.finish_sub_pattern, s.move, s.idle, s.idle,

        s.fire_search, 

        s.idle, s.move, s.idle, s.idle, s.move, s.idle, 

        s.fire_snake
        
    }


    self.ThrowType = {
        NORMAL = 1,
        TWO = 2,
        EXTRA = 3
    }

    self.next_throw = self.ThrowType.NORMAL
    self.throw_number = 0

    self.pattern_index = 1
    self.in_sub_pattern = false
    self.nloop = 1
    self.idle_count = 0
    self.mloop = 3
    self.move_count = 0
    self.volley_loop = 2
    self.volley_count = 0

    self.acting = false
    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    self.spell_circle = nil
    self.spell_circle_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.spell_circle_component.update_func = function()
        if self.first_act and self.apollo_active and not self.spell_circle and (self.state == self.states.fire_shot or self.state == self.states.fire_search) then 
            spawn_spell_circle(self)
        end
    end

    self:register_component(self.spell_circle_component)


    self.apollo_soul_check = Battle.Component.new(self, Lifetimes.Battlestep)

    self.apollo_check_frame = 0
    self.apollo_attempted = false
    self.can_attempt_apollo = false
    self.apollo_soul_check.update_func = function()
        if not self.can_attempt_apollo and self.ring1_anim == nil and self:get_health() <= self.max_health/2 then 
            self.can_attempt_apollo = true
  
        end

        if self.can_attempt_apollo and not self:is_sliding() and self.apollo_check_frame % 2 == 1 then 
        --    print("Apollo Soul")
            self:card_action_event(apollo_soul_action(self), ActionOrder.Immediate)
            self.apollo_attempted = true
        end

        if self.can_attempt_apollo and not self:is_sliding() then  
            self.apollo_check_frame = self.apollo_check_frame + 1
        end
        
    end

    self:register_component(self.apollo_soul_check)

    self.ring1 = self:create_node()
    self.ring1_anim = nil

    self.ring2 = self:create_node()
    self.ring2_anim = nil

    self.ring3 = self:create_node()
    self.ring3_anim = nil

    self.behavior = "NORMAL"
    self.apollo_active = false
    self.apollo_buff = 20

    self.combo_hit = false
    


    self.hit_func = function()
   --     print("Hit")
        self.flinching = false
        self.first_act = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.first_flinch then 
         --   self.state.cleanup
            self.last_state = self.state
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end
        self.state = self.states.flinch
        if self.slide_component ~= nil then 
          --  print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)

            if self.slide_dest and self:get_current_tile() ~= self.slide_dest then 
            --    print("Hit before reaching destination.")
                self:get_current_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end

        end
        flinch(self)

    end

    self.delete_func = function(self)
        self.update_func = function(self)
            anim:set_state("FLINCH")
            self.state = self.states.flinch
        end

    end


    self.end_attack = false
    self.moving_to_enemy_tile = false
    self.spinning = false
    self.slide_component = nil
    self.slide_dest = nil
    self.counter = 0
    self.kick_count = 3
    self.collision_available = true


    self:register_status_callback(Hit.Stun, self.hit_func)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    self:register_status_callback(Hit.Drag, self.hit_func)

    -- Bring it back next build. For now, relying on the stun callback
    --[[
    self.on_countered = function(self)
        print("Countered")
        self:toggle_counter(false)
        self.hit_func(self)

    end
    --]]

    self.can_move_to_func = function(tile)
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({})) then
            return false
        end

        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end

        return not check_obstacles(tile, self) --and not check_characters(tile, self)
    end

    self.update_func = function(self)
      --  print("     ", self.state.name, self.moving_to_enemy_tile)
        self.state.func(self)
        check_collision(self)
    end
end

function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())

    local damage = self.damage
    if self.apollo_active then 
        damage = damage + self.apollo_buff
    end
    local hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self, dt)
        tile:attack_entities(self)
        self:delete()
    end

    self:get_field():spawn(spell, tile)
end


-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_current_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end

end

function idle(self)
    if self.first_act then 
        if anim:get_state() ~= "IDLE" then 
            anim:set_state("IDLE")
        end
        anim:set_playback(Playback.Loop)

        anim:on_complete(function()
            if not self.looped then 
                --self.looped = true
                self.idle_count = self.idle_count+1
               -- print("Complete"..self.idle_count)

                if self.idle_count >= self.nloop then 
                    self.state_done = true
                    
                end
            end

            self.looped = not self.looped
        
        end)

        self.first_act = false
    end

    --self.looped = false
    if self.state_done then 
       -- print("State done")
        self.idle_count = 0
        self.state_done = false
        increment_pattern(self)
    end
end

function hit()
    

end

function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end

    self.throw_number = 0
    self.next_throw = self.ThrowType.NORMAL
end

function flinch(self)
   -- print("Flinch played")
    self.looped = false

    if not self.flinching then 
        anim:set_state("FLINCH")        
        anim:on_complete(function()
           -- print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = false

            self.looped = true

        --    print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
           --     print("Last state was not idle or move")

                if not self.in_sub_pattern then 
                    increment_pattern(self)
                else
                    end_sub_pattern(self)
                end

               
            else
             --   print("Last state was idle or move")

                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end

        end)

    end

    self.flinching = true
   
end


function highlight_tiles(self, list, time)
    local spell = Battle.Spell.new(self:get_team())


    local ref = self
    spell.update_func = function(self)
        for i=1, #list
        do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(Highlight.Solid)
            end

        end


        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
    
            end
        end
    end


    self:get_field():spawn(spell, self:get_current_tile())

    return spell
end



function move(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local tile = choose_move(self, self:get_field())

        anim:on_frame(2, function()
            if self.can_move_to_func(tile) then 
               -- print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
                --print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end


function fire_shot(self)
    if self.first_act then 
        anim:set_state("PUNCH1")

        anim:on_frame(1, function()
            self:toggle_counter(true)
            Engine.play_audio(FIRE_PROJECTILE_SFX, AudioPriority.Low)
            create_fire_shot(self)
        end)
        anim:on_frame(4, function()
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end

end

function create_fire_shot(self)
    local field = self:get_field()
    local spell = graphic_init("spell", 0, 0, texture, "Yuki.animation", -4, "FIRE1", self, self:get_facing())
    spell:get_animation():on_complete(function()
        spell:get_animation():set_state("FIRE1_LOOP")
        spell:get_animation():refresh(spell:sprite())
        spell:get_animation():set_playback(Playback.Loop)
        spell.start_moving = true
    end)
    local facing = self:get_facing()

    local damage = self.damage
    if self.apollo_active then 
        damage = damage + self.apollo_buff
    end
    local hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )

    spell:set_hit_props(hit_props)

    local speed = 6
    if self.apollo_active then 
        speed = 4
    end
    spell.update_func = function(self, dt)
        if not self.start_moving then 
            return 
        end
        self:get_tile():attack_entities(self)
        spell:get_current_tile():highlight(Highlight.Solid)

        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()

            end 
            
            local dest = self:get_tile(facing, 1)
            local ref = self
            self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary,
                function()
                    ref.slide_started = true 
                end
            )
        end
        
    end

    anim:on_interrupt(function()
        if not spell.start_moving then 
            spell:delete()
        end
    end)

    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
        
    end


    spell.collision_func = function()
        local hit_effect = graphic_init("artifact", 0, 0, texture, "Yuki.animation", -4, "FIRE1_HIT", self, spell:get_facing(), true)
        field:spawn(hit_effect, spell:get_current_tile())
        spell:delete()
    end

    spell.can_move_to_func = function()
        return true
    end

   -- Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
    local tile = self:get_tile(facing, 1)

    if tile then 
        field:spawn(spell, tile)
    end
end

function combo(self)
    if self.first_act then 
        self.combo_hit = false

        anim:set_state("PUNCH_COMBO")

        local spells = {}
        anim:on_frame(1, function()
            self:toggle_counter(true)

            table.insert(spells, highlight_tiles(self, {self:get_tile(self:get_facing(), 1)}, 66))

        end)
        anim:on_frame(2, function()
            self:toggle_counter(false)

            table.insert(spells, punch_attack(self, 1))
        end)

        anim:on_frame(5, function()
            table.insert(spells, punch_attack(self, 2))
        end)

        anim:on_frame(9, function()
            Engine.play_audio(FIRE_KICK, AudioPriority.Low)
            table.insert(spells, punch_attack(self, 3))
        end)

        anim:on_interrupt(function()
            for i=1, #spells
            do
                if not spells[i]:is_deleted() then
                    spells[i]:delete()
                end
            end
        end)

        anim:on_complete(function()
            if self.combo_hit or not self.apollo_active then 
             --   print("Combo hit was ", self.combo_hit)
                end_sub_pattern(self)
            else
                increment_pattern(self)
            end
        
        end)

        self.first_act = false
    end

end

function punch_attack(self, num, from_spin)
    from_spin = from_spin or false
    local spell = Battle.Spell.new(self:get_team())
    local effect = graphic_init("spell", 0, 0, texture, "Yuki.animation", -4, "HIT_EFFECT"..num, self, self:get_facing(), true)
    local field = self:get_field()
    local tile = self:get_tile(self:get_facing(), 1)
    local hit_props = nil

    if from_spin then 
        spell:highlight_tile(Highlight.Solid)
    end

    local damage = self.damage
    if self.apollo_active then 
        damage = damage + self.apollo_buff
    end

    if from_spin or (num < 3 and not from_spin) then 
        hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )
    else
        hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Drag,
            Element.Fire, 
            self:get_id(), 
            Drag.new(self:get_facing(), self:get_field():width())
        )
    end
    spell:set_hit_props(hit_props)

    local lifetime = 12
    spell.update_func = function(self)
        self:get_tile():attack_entities(self)

        lifetime = lifetime - 1
        if lifetime == 0 then 
            self:delete()
         --   print("Spell deleted")
        end
    end



    local function check_behind(other, is_behind)
        local spell = Battle.Spell.new(self:get_team())
        local tile = other:get_tile(other:get_facing_away(), 1)

        local hit_props = HitProps.new(
            50,
            Hit.Impact | Hit.Breaking,
            Element.None, 
            self:get_id(), 
            Drag.None
        )

        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            self:delete()
        end

        

        spell.collision_func = function()
            if not is_behind then 
                check_behind(other, true)
            end
        end

        if is_behind then 
            tile = other:get_tile()
        end

        field:spawn(spell, tile)
    end


    spell.attack_func = function(self, other)
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
        self.combo_hit = true
       -- print("Combo hit true now")
        if num < 3 or from_spin then return end
        local slide_check = Battle.Component.new(other, Lifetimes.Local)


        local not_sliding = 0
        slide_check.update_func = function()
            if not other:is_sliding() then 
                if not_sliding == 1 then
                    other:get_tile(Direction.Up, 1):set_state(TileState.Cracked)
                    other:get_tile(Direction.Down, 1):set_state(TileState.Cracked)
                    other:get_tile():set_state(TileState.Cracked)
                    check_behind(other, false)

                    local shake_artifact = Battle.Artifact.new()
                    local time = 0
                    shake_artifact.update_func = function(self)
                            
                        self:shake_camera(150, 0.016)
                        if time == 24 then 
                            self:delete()
                        end
                    
                        time = time+1
                    end

                    field:spawn(shake_artifact, tile)

                    Engine.play_audio(BREAK_SFX, AudioPriority.Low)

                    slide_check:eject()
                end
                not_sliding = not_sliding+1
            else
                not_sliding = 0
            end

        end


        other:register_component(slide_check)
    end

    field:spawn(spell, tile)
    field:spawn(effect, tile)

    return spell
end


function choose_kick(self, pref)
    pref = pref or nil
    local t = self:get_current_tile()
    local x = t:x()
    local y = t:y()
    local possible = {}

    --if y > 1 then
    if self.can_move_to_func(t:get_tile(Direction.Down, 1)) then
        table.insert(possible, "down")
    end
   -- end

   -- if y < 3 then 
    if self.can_move_to_func(t:get_tile(Direction.Up, 1)) then
        table.insert(possible, "up")
    end
   -- end

    if self.can_move_to_func(t:get_tile(self:get_facing_away(), 1)) then
        table.insert(possible, "back")
    end


    if #possible == 0 then 
        table.insert(possible, "up")
        table.insert(possible, "down")
        table.insert(possible, "back")
    else
        choice = possible[math.random(#possible)]
    end

    if choice == "up" then
        spin_kick_up(self) 
        self.state = self.states.spin_kick_up
    elseif choice == "down" then 
        self.state = self.states.spin_kick_down
    else
        spin_kick_back(self)
        self.state = self.states.spin_kick_back
    end

end

function spin_kick_up(self)
    if self.first_act then 
        anim:set_state("SPIN_KICK_"..self.behavior)

        anim:on_frame(3, function()
            self:toggle_counter(true)
            create_fire_wave(self, Direction.Up)
        end)
        anim:on_frame(5, function()
            if self.can_move_to_func(self:get_tile(Direction.Up, 1)) then 
                local time = 18
                if self.apollo_active then 
                    time = 10
                end
                move_slide(self, Direction.Up, time)
            end
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end

function spin_kick_down(self)
    if self.first_act then 
        anim:set_state("SPIN_KICK_"..self.behavior)

        anim:on_frame(3, function()
            self:toggle_counter(true)
            create_fire_wave(self, Direction.Down)
        end)
        anim:on_frame(5, function()
            if self.can_move_to_func(self:get_tile(Direction.Down, 1)) then 
                local time = 18
                if self.apollo_active then 
                    time = 10
                end
                move_slide(self, Direction.Down, time)
            end
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end

function spin_kick_back(self)
    if self.first_act then 
        anim:set_state("SPIN_KICK_"..self.behavior)

        anim:on_frame(3, function()
            self:toggle_counter(true)
            create_fire_wave(self, self:get_facing())
        end)
        anim:on_frame(5, function()
            if self.can_move_to_func(self:get_tile(self:get_facing_away(), 1)) then 
                local time = 18
                if self.apollo_active then 
                    time = 10
                end
                move_slide_horizontal(self, self:get_facing_away(), time)
            end
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end

function move_slide_horizontal(self, direction, moveTime)
    Engine.play_audio(SPIN_SFX, AudioPriority.Low)
    self.slide_component = Battle.Component.new(self, Lifetimes.Battlestep)
    local startPosition = 0
    local target = -80
    if direction == Direction.Right then 
        target = target * -1
    end
    local elapsedMoveTime = 0
    local delta = 0

    local interp = 0
    local tileOffset = 0 
    local t = self:get_tile(direction, 1);
    self.slide_dest = t
    t:reserve_entity_by_id(self:get_id())

    local moved = false;
    local already_moved = false;
    self.slide_component.update_func = function()
        if delta >= 0.5 and not moved then 
            target = 0
        end
        
        delta = math.max(math.min(elapsedMoveTime, moveTime), 0)/moveTime
        interp =  target * delta + (startPosition * (1 - delta))
        
        tileOffset = interp - startPosition
        if delta >= 0.5 then
            tileOffset = -1*target + startPosition + tileOffset
        end

        if not already_moved then 
            t:reserve_entity_by_id(self:get_id())
        end

        -- Offsets are reflected a frame later than they're set
            -- So this moves us a frame later than we set an offset 
            -- for the new panel
        if moved and not already_moved then 
            already_moved = true
            start_tile = self:get_current_tile()
            start_tile:get_tile(direction, 1):add_entity(self)
            start_tile:remove_entity_by_id(self:get_id())
            self.slide_dest = nil
        end

        if delta >=0.5 and not moved then             
            moved = true

        end

        self:set_offset(tileOffset, 0)


        if elapsedMoveTime == moveTime then 
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)


        end

        elapsedMoveTime = elapsedMoveTime + 1

    end


    self:register_component(self.slide_component)

  
end


function move_slide(self, direction, time)
    Engine.play_audio(SPIN_SFX, AudioPriority.Low)
    time = time or nil
    self.slide_component = Battle.Component.new(self, Lifetimes.Battlestep)
    local startPosition = 0
    local target = -50
    if direction == Direction.Down then 
        target = target * -1
    end
    local moveTime = 18
    if time then 
        moveTime = time
    end
    local elapsedMoveTime = 0
    local delta = 0

    local interp = 0
    local tileOffset = 0 
    local t = self:get_tile(direction, 1);
    self.slide_dest = t
    t:reserve_entity_by_id(self:get_id())

    local moved = false;
    local already_moved = false;
    self.slide_component.update_func = function()
        if delta >= 0.5 and not moved then 
            target = 0
        end
        
        delta = math.max(math.min(elapsedMoveTime, moveTime), 0)/moveTime
        interp =  target * delta + (startPosition * (1 - delta))
        
        tileOffset = interp - startPosition
        if delta >= 0.5 then
            tileOffset = -1*target + startPosition + tileOffset
        end

        if not already_moved then 
            t:reserve_entity_by_id(self:get_id())
        end

        -- Offsets are reflected a frame later than they're set
            -- So this moves us a frame later than we set an offset 
            -- for the new panel
        if moved and not already_moved then 
            already_moved = true
            start_tile = self:get_current_tile()
            start_tile:get_tile(direction, 1):add_entity(self)
            start_tile:remove_entity_by_id(self:get_id())
            self.slide_dest = nil
        end

        if delta >=0.5 and not moved then             
            moved = true

        end

        self:set_offset(0, tileOffset)


        if elapsedMoveTime == moveTime then 
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)


        end

        elapsedMoveTime = elapsedMoveTime + 1

    end


    self:register_component(self.slide_component)

  
end



function move_slide_awful_version(self, direction)
    self.slide_component = Battle.Component.new(self, Lifetimes.Battlestep)
    local duration = 22
    local time = duration
    local t = self:get_tile(direction, 1);
    self.slide_dest = t
    t:reserve_entity_by_id(self:get_id())
    local d_y = (t:height())/duration

    if direction == Direction.Up then 
        d_y = d_y * -1
    end

    local y = 0
    local moved = 0;
    local already_moved = false;
    self.slide_component.update_func = function()
        y = y + d_y
        if not already_moved then 
            t:reserve_entity_by_id(self:get_id())
        end
        -- Offsets are reflected a frame later than they're set
            -- So this moves us a frame later than we set an offset 
            -- for the new panel
        if moved ~= 0 and not already_moved then 
            already_moved = true
            start_tile = self:get_current_tile()
            start_tile:get_tile(direction, 1):add_entity(self)
            start_tile:remove_entity_by_id(self:get_id())
            self.slide_dest = nil
        end

        if time-3 <= duration/2 and moved == 0 then             
            moved = 1
            if direction == Direction.Down then 
                moved = -1
            end

            y = (y) * -1
            time = time-4

        end

        self:set_offset(0, y)


        if time == 0 then 
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)


        end

        time = time - 1

    end


    self:register_component(self.slide_component)

  
end

function create_fire_wave(self, dir)
    local field = self:get_field()
    local state = "FIRE_WAVE_"..self.behavior
    local last = 4
    local dir2 = Direction.Down
    if dir == Direction.Left or dir == Direction.Right then 
        state = "FIRE_SPIKE_"..self.behavior
        last = 3
        dir2 = self:get_facing()
    end
    local spell = graphic_init("spell", 0, 0, texture, "Yuki.animation", -4, state, self, self:get_facing())
    spell:get_animation():on_frame(last, function()
        spell.start_moving = true
    end)
    local facing = self:get_facing()

    local damage = self.damage
    if self.apollo_active then 
        damage = damage + self.apollo_buff
    end
    local hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self, dt)
        if not self.start_moving then 
            return 
        end
        self:get_tile():attack_entities(self)
        local t2 = spell:get_tile(dir2, 1)
        
        if t2 and not t2:is_edge() then
            t2:attack_entities(self)
            t2:highlight(Highlight.Solid)
        end

        spell:get_current_tile():highlight(Highlight.Solid)


        if self:is_sliding() == false then
            if not self:get_tile(facing, 1) and self.slide_started then 
                self:delete()

            end 
            
            local dest = self:get_tile(facing, 1)
            local ref = self
            self:slide(dest, frames(9), frames(0), ActionOrder.Voluntary,
                function()
                    ref.slide_started = true 
                end
            )
        end
        
    end


    anim:on_interrupt(function()
        if not spell.start_moving then 
            spell:delete()
        end
    end)

    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end


    spell.collision_func = function()
       -- spell:delete()
    end

    spell.can_move_to_func = function()
        return true
    end

   -- Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
    local tile = self:get_tile(facing, 1)
    if dir == Direction.Up then 
        tile = tile:get_tile(Direction.Up, 1)
    end

    if dir == Direction.Left or dir == Direction.Right then 
        tile = self:get_current_tile()
    end

    if tile then 
        field:spawn(spell, tile)
    end
end


function spin_kick_column(self)
    -- 1 4 7
    if self.first_act then 
        self.counter = 0
        self.kick_count = 3
        self:toggle_counter(true)
        anim:set_state("SPIN_KICK_START_"..self.behavior)
        anim:refresh(self:sprite())

        anim:on_complete(function()
   --         print("Changing to looping")
            anim:set_state("SPIN_KICK_LOOP_"..self.behavior)
            anim:set_playback(Playback.Loop)
            anim:refresh(self:sprite())
            self:toggle_counter(false)
            
            
        end)
        
        

        self.first_act = false
    end

    if anim:get_state() == "SPIN_KICK_LOOP_"..self.behavior then 
        self.counter = self.counter+1
        local period = 14
        if self.apollo_active then 
            period = 10
        end
        if self.counter % period == 1 then 
            punch_attack(self, self.kick_count, true)
            self.kick_count = self.kick_count - 1
            if self.kick_count < 0 then 
                self.kick_count = 3
            end
        end

        if self.slide_component == nil then 
            if self.can_move_to_func(self:get_tile(Direction.Down, 1)) then 
                local time = 12
                if self.apollo_active then 
                    time = 8
                end
                move_slide(self, Direction.Down, time)
            else
                self.moving_to_enemy_tile = false

                anim:on_complete(function()
                    anim:set_state("SPIN_KICK_END_"..self.behavior)
                    anim:refresh(self:sprite())

                    anim:on_complete(function()
                        increment_pattern(self)
                    end)
                end)
            end
        end
    end

end


function throw(self)
    if self.first_act then 
        anim:set_state("THROW")

        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)

        anim:on_frame(6, function()
            Engine.play_audio(THROW_SFX, AudioPriority.Low)
            local throw = self.next_throw
            if self.next_throw == self.ThrowType.EXTRA and self.throw_number == 1 then 
                throw = self.ThrowType.NORMAL
            end
            throw_bomb(self, throw)
            self.throw_number = self.throw_number + 1

            if self.apollo_active and self.next_throw ~= self.ThrowType.EXTRA and self.throw_number ~= 2 then 
                local choice = math.random(1, 2)
                if choice == 1 then 
                --    print("Chose two.")
                    self.next_throw = self.ThrowType.TWO
                elseif choice == 2 then 
                  --  print("Chose extra")
                    self.next_throw = self.ThrowType.EXTRA
                end
            elseif self.next_throw ~= self.ThrowType.EXTRA then 
                self.next_throw = self.ThrowType.NORMAL
            end


            self:toggle_counter(false)
        end)

        anim:on_frame(7, function()
        --    throw_bomb(self, true)
        end)

        anim:on_complete(function()
            if self.throw_number == 2 and (not self.apollo_active or self.next_throw ~= self.ThrowType.EXTRA) then 
           --     print("Chose to end sub pattern")
                end_sub_pattern(self)
            else
                increment_pattern(self)
            end
        
        end)

        self.first_act = false
    end


end

function throw_bomb(self, throw_type, second, avoid_tile)
    second = second or false
    avoid_tile = avoid_tile or nil
    
    local list = self:get_field():find_tiles(function(t)
        if avoid_tile then 
            if t == avoid_tile then 
                return false
            end
        end
        return t:get_team() ~= self:get_team() and not t:is_edge()
    end)

    local target = list[math.random(1, #list)]

    local max_time = 42
    local height = 64
    if throw_type == self.ThrowType.EXTRA then 
        max_time = max_time - 10
        height = height - 12 
    end

    local force = false
    if throw_type == self.ThrowType.TWO then 
        if second then 
            force = "x"
        else
            throw_bomb(self, throw_type, true, target)
            force = "+"
        end
    end

    
    local time = 0
    local y = -64
    local x = -56
    if self:get_facing() == Direction.Right then 
        x = x * -1
    end

    local d_x = x/max_time    
    local d_y = (y-36)/max_time
    local spell = graphic_init("spell", 0, y, texture, "Yuki.animation", -4, "POTION", self, self:get_facing())
    spell:get_animation():set_playback(Playback.Loop)
    local first = true
    local ref = self
    spell.update_func = function(self)
        if first then 
            self:jump(target, height, frames(max_time), frames(0), ActionOrder.Voluntary, nil)

            first = false
        end

        target:highlight(Highlight.Solid)
        if time <= max_time then 
            self:set_offset(x - d_x*time, y - d_y*time)

            time = time + 1
        else
            self:set_offset(x - d_x*time, y - d_y*time)

            time = time + 1
            self:hide()
            spawn_flame(ref, self:get_team(), target, true, force)
            self:delete()
        end
    end


    spell.can_move_to_func = function()
        return true
    end

 

    self:get_field():spawn(spell, self:get_current_tile())

end

function spawn_spell_circle(self)
    Engine.play_audio(APPEAR_SFX, AudioPriority.Low)
    local field = self:get_field()
    local x = 1
    if self:get_facing() == Direction.Left then 
        x = field:width()
    end

    local cur_y = self:get_current_tile():y()

    local possible_y = {}

    for i=1, field:height()
    do
        if i ~= cur_y then 
            table.insert(possible_y, i)
        end
    end


    local circle = graphic_init("spell", 0, 0, texture, "Yuki.animation", 10, "SPELL_CIRCLE_START", self, self:get_facing())

    local count = 0
   
    local anim = circle:get_animation()
    
    anim:on_complete(function()
        anim:set_state("SPELL_CIRCLE_LOOP")
        anim:set_playback(Playback.Loop)
        anim:refresh(circle:sprite())
        local counter = 36
        local shots = 3
        circle.update_func = function()
            if counter % 48 == 0 then 
                if shots == 0 then 
                    anim:set_state("SPELL_CIRCLE_CLOSE")
                    circle.update_func = function()
                    end
                    anim:on_complete(function()
                        circle:delete()
                        self.spell_circle = nil
                    end)


                    anim:refresh(circle:sprite())

                else
                    Engine.play_audio(FIRE_PROJECTILE_SFX, AudioPriority.Low)
                    spell_circle_shoot(self, circle)
                    shots = shots - 1
                end

            end

            counter = counter + 1

        end
    end)

    self.spell_circle = circle
    field:spawn(circle, field:tile_at(x, possible_y[math.random(1, #possible_y)]))
end


function spell_circle_shoot(self, circle)
    local field = self:get_field()
    local spell = graphic_init("spell", 0, 0, texture, "Yuki.animation", -4, "SPELL_CIRCLE_SHOT", self, circle:get_facing())

    spell:get_animation():set_playback(Playback.Loop)
    local facing = self:get_facing()

    local hit_props = HitProps.new(
            30,
            Hit.Impact | Hit.Flinch,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self, dt)
        if not spell:get_current_tile():is_edge() then 
            self:get_tile():attack_entities(self)
            spell:get_current_tile():highlight(Highlight.Solid)
        end

        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()

            end 
            
            local dest = self:get_tile(facing, 1)
            local ref = self
            self:slide(dest, frames(12), frames(0), ActionOrder.Voluntary,
                function()
                    ref.slide_started = true 
                end
            )
        end
        
    end


    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end


    spell.collision_func = function()
        local hit_effect = graphic_init("artifact", 0, 0, texture, "Yuki.animation", -4, "SPELL_CIRCLE_SHOT_HIT", self, spell:get_facing(), true)
        field:spawn(hit_effect, spell:get_current_tile())
        spell:delete()
    end

    spell.can_move_to_func = function()
        return true
    end

   -- Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
    local tile = circle:get_current_tile()

    if tile then 
        field:spawn(spell, tile)
    end

end

function fire_search(self)
    if self.first_act then 
        anim:set_state("FIRE_SEARCH")

        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)

        anim:on_frame(5, function()
            Engine.play_audio(SEARCH_SFX, AudioPriority.Low)
            start_search(self)
            self:toggle_counter(false)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end

function start_search(self)
    local circles = {}
    local field = self:get_field()
    local circle_controller = Battle.Spell.new(self:get_team())

    for i=1, 4
    do
        circles[i] = graphic_init("spell", 0, 0, texture, "Yuki.animation", 20, "SMALL_CIRCLE", self, self:get_facing())
        circles[i].can_move_to_func = function()
            return true
        end
        
        circles[i].turn_count = 0
    end

    circles[1].is_further = true
    circles[3].is_further = true
    circles[3].is_lower = true
    circles[4].is_lower = true

    -- X of top right circle
        -- Well, top left if facing right. Unsure, but hopefully
    local x = 0
    local dir = 1
    if self:get_facing() == Direction.Left then 
        x = field:width()+1
        dir = dir * -1
    end

    -- Y of top right circle
    local y = 1 
    if math.random(1, 2) == 2 then 
        -- Subtract 1 since this is top right circle
        y = field:height() - 1
    end

    local tiles = {
        field:tile_at(x, y),
        field:tile_at(x+dir, y),
        field:tile_at(x, y+1),
        field:tile_at(x+dir, y+1)
    }


    local second_dir = Direction.Up
    if y == 1 then 
        second_dir = Direction.Down
    end

    for i=1, #circles
    do
        circles[i].slide_dir = self:get_facing()
        circles[i].orig_dir = self:get_facing()
        circles[i].second_dir = second_dir
    end




    local function is_under_character(self)
        if check_characters(self:get_current_tile(), self) then 
            return true
        end

        return false
    end
   

    local time = 12
    if self.apollo_active then 
        time = 8
    end
    local function circle_update(self)
        if self.turn_count == 0 then 
            if self:get_tile(self.slide_dir, 1):is_edge() or self.is_further and self:get_tile(self.slide_dir, 2):is_edge() then 
                self.slide_dir = self.second_dir
                self.turn_count = self.turn_count+1

            end


        elseif self.turn_count == 1 then
            if self:get_tile(self.slide_dir, 1):is_edge() or (self.is_lower or not self.is_lower and self.slide_dir == Direction.Down) and self:get_tile(self.slide_dir, 2):is_edge() then 
                self.slide_dir = Direction.reverse(self.orig_dir)
                self.turn_count = self.turn_count+1

            end

        end

        if not self:get_tile(self.slide_dir, 1) then 
            self:delete()
            return
        end 
        
        local dest = self:get_tile(self.slide_dir, 1)
        local ref = self
        self:slide(dest, frames(time), frames(0), ActionOrder.Voluntary,
            function()
                ref.slide_started = true 
            end
        )
        

    end


    local attacking = false
    local interrupted
 --   if not self.apollo_active then 
        anim:on_interrupt(function()
            interrupted = true
        end)
   -- end
    circle_controller.update_func = function()
        local exists = true
        -- Check if at least one circle exists
        if interrupted and not attacking then 
            for i=1, #circles
            do
                if not circles[i]:is_deleted() then
                    circles[i]:delete()
                end
            end

            circle_controller:delete()
            return
        end

        for i=1, #circles
        do
            exists = exists or not circles[i]:is_deleted()
        end

        if not exists then 
      --      print("Controller deleted")
            circle_controller:delete()
            return
        end

        local sliding = true
        for i=1, #circles
        do
            if not circles[i]:is_deleted() then
                sliding = sliding and circles[i]:is_sliding()
            end
        end

        if not attacking and not sliding then
            local should_attack = false
            for i=1, #circles
            do
                if not circles[i]:is_deleted() then
                    should_attack = should_attack or is_under_character(circles[i])
                end
            end

            if should_attack then 
                attacking = true
                local first = true
                Engine.play_audio(LOCK_ON_SFX, AudioPriority.Low)
                for i=1, #circles
                do
                    if not circles[i]:is_deleted() then
                        start_circle_attack(circles[i], self, first)
                        first = false
                    end
                end

                anim:set_state("FIRE_SEARCH_FINISH")
                anim:on_complete(function()
                    increment_pattern(self)
                end)

                circle_controller:delete()
                return

            else
                for i=1, #circles
                do
                    if not circles[i]:is_deleted() then
                        circle_update(circles[i])
                    end
                end
            end
        end

    end



    field:spawn(circle_controller, field:tile_at(0, 0))
    for i=1, #tiles
    do
        field:spawn(circles[i], tiles[i])
    end
end

function start_circle_attack(circle, self, first)
    circle:get_animation():set_state("CIRCLE_ACTIVATE")
    circle:get_animation():refresh(circle:sprite())
    circle:get_animation():on_frame(3, function()
        if first then 
            Engine.play_audio(FLAME_PILLAR_SFX, AudioPriority.Low)
        end

        spawn_circle_flame(circle, self)
    end)

    circle:get_animation():on_complete(function()
        circle:delete()
    end)

end

function spawn_circle_flame(circle, self)
    local flame = graphic_init("spell", 0, 0, texture, "Yuki.animation", -4, "CIRCLE_FLAME", circle, circle:get_facing())
    local field = circle:get_field()
    local first = true

    local function create_attack(duration)
        local spell = Battle.Spell.new(circle:get_team())

        local damage = self.damage
        if self.apollo_active then 
            damage = damage + self.apollo_buff
        end
        local hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )

        spell:set_hit_props(hit_props)

        local lifetime = duration
        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
            lifetime = lifetime - 1
            if lifetime == 0 then 
                spell:delete()
            end
        end

        spell.attack_func = function()
            Engine.play_audio(HIT_SFX, AudioPriority.Low)
        end

        field:spawn(spell, circle:get_current_tile())
    end

    create_attack(48)
    field:spawn(flame, circle:get_current_tile())
end


function fire_snake(self)
    if self.first_act then 
        anim:set_state("FIRE_SNAKE_"..self.behavior)

        anim:on_frame(1, function()
            self:toggle_counter(true)
        end)

        anim:on_frame(3, function()
            spawn_snake_circles(self, 4)
            self:toggle_counter(false)
        end)

        if self.apollo_active then 
            anim:on_frame(8, function()
                spawn_snake_circles(self, 4)
            end)
            anim:on_frame(9, function()
                spawn_snake_circles(self, 4)
            end)
        end

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end


end


function spawn_snake_circles(self, num)
    local possible_tiles = {}
    local tiles_picked = {}
    local pairs = {}
    local field = self:get_field()
    local first = true

    local dirs = {
        Direction.Up, 
        Direction.Down, 
        Direction.Left, 
        Direction.Right
    }

    local function check_possible()
        -- Clear list each call
        possible_tiles = {}
        for y=1, field:height()
        do
            for x=1, field:width()
            do
                local t = field:tile_at(x, y)
                local exists = false
                for i=1, #tiles_picked
                do
                    exists = exists or t == tiles_picked[i]
                end
                if not exists then 
                    table.insert(possible_tiles, t)
                end
            end
    
        end
    end

   
    local function pick_tile()
        local pick = possible_tiles[math.random(1, #possible_tiles)]
        local second = nil

        local pos_second = {}

        for i=1, #dirs
        do
            local t = pick:get_tile(dirs[i], 1)
            if not t:is_edge() then 
                local exists = false
                for j=1, #tiles_picked
                do
                    exists = exists or t == tiles_picked[j]
                end

                if not exists then 
                    table.insert(pos_second, t)
                end
            end

        end

        if #pos_second ~= 0 then 
            second = pos_second[math.random(1, #pos_second)]
            table.insert(tiles_picked, second)
            table.insert(tiles_picked, pick)

            table.insert(pairs, {pick, second})
        else
            -- Not possible to pick two tiles at chosen spot. Find another, and mark this one as bad
            table.insert(tiles_picked, pick)
            check_possible()
            pick_tile()
        end
    end

    
    local function create_circle(pair, first)
        first = first or false
        local spell1 = graphic_init("spell", 0, 0, texture, "Yuki.animation", 20, "SNAKE_CIRCLE", self, self:get_facing(), true)
        local spell2 = graphic_init("spell", 0, 0, texture, "Yuki.animation", 20, "SNAKE_CIRCLE", self, self:get_facing(), true)

        local jumper = Battle.Spell.new(self:get_team())
        jumper.can_move_to_func = function()
            return true
        end

        local function create_flame(tile, x, y)
            local flame = graphic_init("spell", x*-1, y, texture, "Yuki.animation", -4, "SNAKE_FLAME", self, self:get_facing(), true)

            field:spawn(flame, tile)
        end

        

        local time = 0
        local jump_time = 24
        local first = true
        local flame_number = 1
        local offset = nil
        local height = 40
        jumper.is_horizontal = (pair[1]:y() == pair[2]:y())
        if not jumper.is_horizontal then 
            height = 24
        end

        local function create_flame_attack(tile)
            local lifetime = 42
            local spell = Battle.Spell.new(self:get_team())

            local damage = self.damage
            if self.apollo_active then 
                damage = damage + self.apollo_buff
            end
            local hit_props = HitProps.new(
                damage,
                Hit.Impact | Hit.Flash | Hit.Flinch,
                Element.Fire, 
                self:get_id(), 
                Drag.None
            )

            spell:set_hit_props(hit_props)

            spell.update_func = function()
                spell:get_current_tile():attack_entities(spell)
                lifetime = lifetime - 1
                if lifetime == 0 then 
                    spell:delete()
                end
            end

            spell.attack_func = function()
                Engine.play_audio(HIT_SFX, AudioPriority.Low)
            end

            field:spawn(spell, tile)
        end

        jumper.update_func = function(self)
            if not first then 
                if time % 6 == 0 then 
                    if flame_number == 2 or (self.is_horizontal and flame_number == 4) then 
                        create_flame(jumper:get_current_tile(), offset.x, offset.y)
                        offset.x = offset.x * -1
                    else
                        create_flame(jumper:get_current_tile(), jumper:get_tile_offset().x, jumper:get_tile_offset().y)
                    end
                    if flame_number == 1 or flame_number == 4 then 
                        create_flame_attack(jumper:get_current_tile())
                    end
                    flame_number = flame_number+1
                end

                if ((not self.is_horzontal and time % 6 == 4) or (self.is_horizontal and time % 6 == 5)) and flame_number == 2 then 
                    offset = jumper:get_tile_offset()
                end
                time = time + 1

                if time > jump_time+3 then
                    jumper:delete()
                end 
            end
            if first then 
                jumper:jump(spell2:get_current_tile(), height, frames(jump_time), frames(0), ActionOrder.Voluntary, nil)
                first = false
            end

            
        end

        spell1:get_animation():on_frame(5, function()
            if first then 
                Engine.play_audio(SNAKE_SFX, AudioPriority.Low)
            end
            field:spawn(jumper, spell1:get_current_tile())

        end)

        field:spawn(spell1, pair[1])
        field:spawn(spell2, pair[2])
    end

    for i=1, num
    do
        check_possible()
        pick_tile()
        create_circle(pairs[i], first)
        first = false
    end

end



function spawn_flame(self, team, tile, from_bomb, force)
    Engine.play_audio(EXPLOSION_SFX, AudioPriority.Low)
    force = force or nil
    local field = self:get_field()
    local flame = graphic_init("spell", 0, 0, texture, "Yuki.animation", -4, "POTION_EXPLOSION", self, self:get_facing(), true)
    local tiles
    local spell = Battle.Spell.new(team)
    spell:set_name("Element.Poison")
    if from_bomb then 
        pos_tiles = {
            tile:get_tile(Direction.Up, 1),
            tile:get_tile(Direction.Left, 1),
            tile:get_tile(Direction.Down, 1),
            tile:get_tile(Direction.Right, 1)
        }

        pos_tiles2 = {
            tile:get_tile(Direction.UpLeft, 1),
            tile:get_tile(Direction.UpRight, 1),
            tile:get_tile(Direction.DownLeft, 1),
            tile:get_tile(Direction.DownRight, 1)
        }

        local selection = math.random(0, 1)

        if selection == 0 then 
            tiles = pos_tiles
        else
            tiles = pos_tiles2
        end

        if force and force == "+" then 
            tiles = pos_tiles
        elseif force and roce == "x" then 
            tiels = pos_tiles2
        end

    end

    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.None, 
        self:get_id(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    local lifetime = 18

    
    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
        lifetime = lifetime - 1
        if lifetime == 0 then 
            self:delete()
        end
    end


    local function attach_poison(other)
        if not Battle.Character.from(other) then 
            return
        end
        -- Use find spells and get rid of health later
        local list = field:find_entities(function(e) return e:get_name() == "YUKI_POISON_CONTROLLER"..other:get_id() end)        
        if list[1] then 
            list[1]:set_name("RESET")
            return
        end

        

        local artifact = Battle.Spell.new(other:get_team())
        artifact:set_name("YUKI_POISON_CONTROLLER"..other:get_id())
        artifact:set_health(1)
        -- artifact:toggle_hitbox(true)
        local time_remaining = 360

        local colored = false
        local poison_component = Battle.Component.new(other, Lifetimes.Local)
        local mode = other:sprite():get_color_mode()

        local defense = Battle.DefenseRule.new(2983,DefenseOrder.CollisionOnly)
        local defense_removed = false

        defense.can_block_func = function(judge, attacker, defender)
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.damage > 0 then

                if attacker_hit_props.element == Element.Fire then 
                    attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                    attacker:set_hit_props(attacker_hit_props)
                    other:remove_defense_rule(defense)
                    if not poison_component:is_injected() then 
                        artifact:delete()
                        poison_component:eject()
                        other:sprite():set_color_mode(mode)
                        defense_removed = true
                    end

                end

            end
        end

        other:add_defense_rule(defense)

        poison_component.update_func = function()
            if artifact:is_deleted() then 
                poison_component:eject()
                return
            end
            if artifact:get_name() == "RESET" then
                time_remaining = 360
                artifact:set_name("YUKI_POISON_CONTROLLER"..other:get_id())
            end
            if time_remaining % 8 == 0 then 
                other:set_health(other:get_health()-1)
            end

            -- Defense check is because I'm not sure what being hit by fire on the last frame would do
                -- Could run this tick even though I ejected that same frame
            if time_remaining == 0 and not defense_removed then 
                artifact:delete()
                poison_component:eject()
                other:sprite():set_color_mode(mode)
                other:remove_defense_rule(defense)

            end
            time_remaining = time_remaining - 1

            if time_remaining % 3 == 1 then 
                other:sprite():set_color_mode(ColorMode.Multiply)

            end
            if time_remaining % 3 == 0 then 
                local color = Color.new(150, 20, 40, 255)
                other:set_color(color)
                other:sprite():set_color_mode(mode)

                colored = true
            end
            
        end

        other:register_component(poison_component)
        field:spawn(artifact, field:tile_at(1, 1))

    end

    spell.attack_func = function(self, other)
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
        attach_poison(other)

    end

   

    if from_bomb then
        flame:get_animation():on_frame(3, function()
            highlight_tiles(self, tiles, 12)
        end)
        flame:get_animation():on_frame(5, function()
            for i=1, #tiles
            do
                local t = tiles[i]
                if t and not t:is_edge() then 
                    spawn_flame(self, team, t, false)
                end
            end
        end)
        
    
    end

    field:spawn(flame, tile)
    field:spawn(spell, tile)
   -- Engine.play_audio(BOMB_SFX, AudioPriority.Low)
end


function apollo_soul_action(self)
    local action = Battle.CardAction.new(self, "APOLLO_SOUL")

    local meta = action:copy_metadata()
    meta.time_freeze = true
    meta.skip_time_freeze_intro = false
    meta.shortname = "Apollo Soul"
    action:set_metadata(meta)

    action:add_anim_action(5, function()
        Engine.play_audio(APOLLO_SFX, AudioPriority.Low)
        self.apollo_soul_check:eject()
        self.behavior = "APOLLO"
        self.apollo_active = true

        self.rings = {
            self.ring1,
            self.ring2,
            self.ring3
        }
    
        self.ring_anims = {
            self.ring1_anim,
            self.ring2_anim,
            self.ring3_anim
        }
    
        self.ring1:set_layer(-1)
        self.ring2:set_layer(2)
        self.ring3:set_layer(1)
    
        for i=1, 3
        do
            self.rings[i]:set_texture(texture, false)
            self.ring_anims[i] = Engine.Animation.new(_modpath.."Yuki.animation")
          --  print("Animation is now not nil")
            local an = self.ring_anims[i]
            an:set_state("FIRE_RING_"..i.."_START")
            an:refresh(self.rings[i])
    
            an:on_complete(function()
                an:set_state("FIRE_RING_"..i.."_LOOP")
                an:refresh(self.rings[i])
                an:set_playback(Playback.Loop)
            
            end)
    
        end
    
        local anim_component = Battle.Component.new(self, Lifetimes.Scene)
    
        anim_component.update_func = function(com, dt)
            for i=1, 3
            do
                self.ring_anims[i]:update(dt, self.rings[i])
            end
    
        end
    
        self:register_component(anim_component)
    
    end)


    return action
end


function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and self.can_move_to_func(tile)
    
    end)


    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function move_to_column_in_front_of_target(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)
        local could_move = false
        self.moving_to_enemy_tile = true
        local tile = choose_column_in_front_of_enemy(self, self:get_field())

        anim:on_frame(2, function()
            if tile and self.can_move_to_func(tile) then 
               could_move = true
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
                --print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
            if not could_move then 
                while self.in_sub_pattern
                do
                    increment_pattern(self)
                end
            end
        end)

        self.first_act = false
    end
end

function choose_column_in_front_of_enemy(self, field)
    local team = self:get_team()
    local tile

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    local offset = 1
    if self:get_facing() == Direction.Right then 
        offset = -1
    end

    -- X of tile in front of target
    local x = target[1]:get_current_tile():x() + offset
    for i = 1, field:height()
    do
        local t = field:tile_at(x, i)
        local check = self.can_move_to_func(t)
        if check then 
            return t
        end
    end


    return nil
end

function choose_move_line_up(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return choose_move(self, field)
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if self:get_facing() == Direction.Right then 
        facing = 1
    end

    local tiles = field:find_tiles(function(tile)
        return tile:y() == t_y and facing * (tile:x() - t_x) < 0 and self.can_move_to_func(tile)
    
    end)

   

    if #tiles == 0 then 
      --  print("No valid tiles")
        return choose_move(self, field)
    end


    return tiles[math.random(1, #tiles)]
end

function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if target[1]:get_facing() == Direction.Right then 
        facing = 1
    end

    local tile = field:tile_at(t_x+facing, t_y)

    return tile
end

function choose_move_back(self, field)
    local team = self:get_team()


    local x = 6
    if self:get_facing() == Direction.Right then 
        x = 1
    end

    local tiles = field:find_tiles(function(tile)
        return tile:x() == x and self.can_move_to_func(tile)
    
    end)

    if #tiles == 0 then 
      --  print("No valid tiles")
        return choose_move(self, field)
    end


    return tiles[math.random(1, #tiles)]
end

function choose_move_back_center(self, field)
    local team = self:get_team()

    local x = 6
    local y = 2

    
    if self:get_facing() == Direction.Right then 
        x = 1
    end

    local t = field:tile_at(x, y)

    if not self.can_move_to_func(t) then 
        return choose_move_back(self, field)
    end

    return t
end

function choose_near_front(self, field, p)
    local team = self:get_team()
    
    local x = 6

    local facing = self:get_facing()

    if facing == Direction.Right then 
        x = 1
    end

    local front_tiles = {
        field:tile_at(x, 1),
        field:tile_at(x, 2),
        field:tile_at(x, 3)
    }

    local function find_front_row()
        for i=1, #front_tiles
        do
            t = front_tiles[i]
            for j=1, field:width()
            do
                t = t:get_tile(facing, 1)
                if t and not t:is_edge() and t:get_team() == self:get_team() then 
                    front_tiles[i] = t
                else
                    break
                end
            end
        end
    end


    find_front_row()

    local tiles = {
        front_tiles[2],
        front_tiles[2]:get_tile(Direction.reverse(facing), 1),

        front_tiles[1],
        front_tiles[1]:get_tile(Direction.reverse(facing), 1),

        front_tiles[3],
        front_tiles[3]:get_tile(Direction.reverse(facing), 1)
    }

    if p == self.states.flare then 
        if self.can_move_to_func(tiles[1]) then 
            return tiles[1]
        elseif self.can_move_to_func(tiles[2]) then 
            return tiles[2]
        end
    end


    local j = #tiles
    for i=1, #tiles
    do
        r = math.random(1, #tiles)
        if self.can_move_to_func(tiles[r]) then 
            return tiles[r]
        else
            table.remove(tiles, r)
        end
    end

    return choose_move(self, field)

end

function move_line_up(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local tile = choose_move_line_up(self, self:get_field())

        anim:on_frame(3, function()
            if self.can_move_to_func(tile) then 
               -- print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function move_to_back(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local tile = choose_move_back(self, self:get_field())

        anim:on_frame(3, function()
            if self.can_move_to_func(tile) then 
              --  print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function move_to_back_center(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local tile = choose_move_back_center(self, self:get_field())

        anim:on_frame(3, function()
            if self.can_move_to_func(tile) then 
              --  print("Can reach")
            else
                --print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
                --print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end


function move_near_front(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)

        local next = self.pattern[self.pattern_index+1]
        local tile = choose_near_front(self, self:get_field(), next)

        anim:on_frame(3, function()
            if self.can_move_to_func(tile) then 
           --     print("Can reach")
            else
             --   print("Can't do it now")
                tile = self:get_current_tile()
            end
            self:teleport(tile, ActionOrder.Voluntary, function()
               -- print("Move")
            end)
        end)

        anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end


function move_to_enemy(self)
    if self.first_act then 
        anim:set_state("MOVE_"..self.behavior)
        local could_move = true
        anim:on_frame(3, function()
            local tile = choose_enemy(self, self:get_field())
            
            if not tile then 
                could_move = false
            else
                self.moving_to_enemy_tile = true
                if self.can_move_to_func(tile) then 
                  --  print("Target tile is ", tile:x(), tile:y())
                    self:teleport(tile, ActionOrder.Voluntary, function()

                    end)
                else
                    could_move = false
                end
            end
        end)

        anim:on_complete(function()
            self.moving_to_enemy_tile = false

            if could_move then 
                increment_pattern(self)
            else
                end_sub_pattern(self)
            end
        
        end)

        self.first_act = false
    end
end


function increment_pattern(self)
   -- print("Pattern increment")
    self.end_attack = false
    self.volley_count = 0

    self.first_act = true
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        self.pattern_index = 1
    end

    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
   -- print("Moving to state named ", next_state.name)

    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end

    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        self.next_throw = self.ThrowType.NORMAL
        self.throw_number = 0
        increment_pattern(self)

    end

   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)

end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 and (self.mine1 and not o:get_id() == self.mine1:get_id()) or (self.mine2 and not o:get_id() == self.mine2:get_id())
    end)

    return #ob > 0 
end


function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)

    return #characters > 0

end


function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, true)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(_folderpath..animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end